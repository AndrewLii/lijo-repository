package 文件压缩与解压;

import java.util.Scanner;

public class TotalInterface {
	public static void main(String[] args) {
		int chooice;
		Scanner scan=new Scanner(System.in);
		System.out.println("按“0”开始压缩");
		System.out.println("按“1”开始解压");
		chooice=scan.nextInt();
		switch(chooice) {
		case 0:	
			new Interface();
			break;
		case 1:
			new DecompressInterface();
			break;
		}
	}
}
