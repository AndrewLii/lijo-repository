package 文件压缩与解压;

import java.io.IOException;

public class DecompressInterface {
	DecompressInterface(){
		System.out.println("请先选择压缩文件的哈夫曼编码文件，再选择压缩文件");
		new FileChoose().getInputPath();
		Decompress begin=new Decompress();
		try {
			begin.getHuffmcode();
			System.out.println("哈夫曼编码获取成功，开始解压");
			begin.DecompressBegin();
			System.out.println("解压成功，文件名为：mydecompressfile.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
