package 文件压缩与解压;

import java.util.LinkedList;
import java.io.FileInputStream;

public class HuffmTree {
	public int[] times=new int[256];
	public String[] HuffmCode=new String[256];
	public LinkedList<HuffmNode> tree=new LinkedList<HuffmNode>();
	public FileInputStream fis;
	
	public HuffmTree() throws Exception{
		//权值数组初始化
		for(int i=0;i<times.length;i++) {
			times[i]=0;
		}
		//霍夫曼编码字符串数组初始化
		for(int i =0;i<HuffmCode.length;i++) {
			HuffmCode[i]="";
		}
		//打开文件输入流
		fis=new FileInputStream(FileChoose.InputPath);
		//开始计算个字符所占权重
		countTimes();
	}
	
	private void countTimes()throws Exception{
		int index=0;
		index=fis.read();
		while(index!=-1) {
			times[index]++;		//index值对应读写出来的字符，ASCII码
			index=fis.read();	//指针自增
		}
	}
	
	public  HuffmNode createTree() {
		for(int i=0;i<times.length;i++) {
			if(times[i]!=0) {		//文件中有相应字符的才参与构建节点
				HuffmNode node=new HuffmNode(i,times[i]);
				tree.add(getIndex(node),node);
			}
		}
		
		while(tree.size()>1) {
			HuffmNode firstNode=tree.removeFirst();		
			HuffmNode secondNode=tree.removeFirst();	//第一个已被移除，第二个成为第一个
			HuffmNode fatherNode=new HuffmNode(-1,firstNode.getData()+secondNode.getData());//权值相加，-1：这个节点的Data并不是从文本中读出的，也没有相应的码对照
			fatherNode.setLeft(firstNode);			
			fatherNode.setRigth(secondNode);
			tree.add(getIndex(fatherNode),fatherNode);	//为父节点查找合适的引索，也就是从小到大排个序
		}
		getHuffmNode(tree.getFirst(),"");
		return tree.getFirst();			//返回根节点，此时哈夫曼树创建完毕
	}
	
	public void getHuffmNode(HuffmNode root,String s) {
		if(root.getLeft()!=null) {				
			getHuffmNode(root.getLeft(),s+"0");			//递归向左，添0
		}
		if(root.getRight()!=null) {
			getHuffmNode(root.getRight(),s+"1");		//递归向右，添1
		}
		if(root.getLeft()==null&&root.getRight()==null) {
			HuffmCode[root.getIndex()]=s;				//叶子节点即使我们需要的存着法夫曼码的节点，至于为什么是叶子节点，画图
		}
	}
	
	private int getIndex(HuffmNode node) {
		for(int i=0;i<tree.size();i++) {
			if(node.getData()<=tree.get(i).getData()) {	//从小到大排序
				return i;
			}
		}
		return tree.size();
	}
	
}
