package 文件压缩与解压;

public class HuffmNode {
	private int data;
	private int index;
	private HuffmNode left=null;
	private HuffmNode rigth=null;
	public HuffmNode(int index,int data) {
		this.index=index;
		this.data=data;
	}
		
	public int getData() {
		return this.data;
	}
	
	public int getIndex() {
		return this.index;
	}
	
	public void setLeft(HuffmNode left) {
		this.left=left;
	}
	
	public HuffmNode getLeft() {
		return this.left;
	}
	
	public void setRigth(HuffmNode right) {
		this.rigth=right;
	}
	
	public HuffmNode getRight() {
		return this.rigth;
	}
}
