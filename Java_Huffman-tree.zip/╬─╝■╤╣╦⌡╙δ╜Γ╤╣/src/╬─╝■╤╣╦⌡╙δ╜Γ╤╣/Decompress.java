package 文件压缩与解压;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Decompress {
	private int[] codelength=new int[256];
	private String[] thecode=new String[256];
	private static String ZipPath;
	private static String DatPath;
	private static String FilePath;
	
	Decompress() {
		String path="C:\\Users\\白马\\Desktop\\";
		DatPath=FileChoose.InputPath;
		new FileChoose().getInputPath();
		ZipPath=FileChoose.InputPath;
		FilePath=path+"mydecompressfile"+".txt";
	}
	public void getHuffmcode() throws IOException {
		int index=0;
		int length=0;
		String code="";
		String singlecode="";
		FileInputStream fis=new FileInputStream(DatPath);
		try {
			for(int i=0;i<256;i++) {
				length=fis.read();	//读取256次，获得长度
				codelength[i]=length;
			}
			index=fis.read();
			while(index!=-1) {		//257开始，就是哈夫曼编码了，直接读完
				code+=intChangTostring(index);
				index=fis.read();
			}
			for(int i=0;i<256;i++) {
				if(codelength[i]!=0) {
					singlecode=code.substring(0, codelength[i]);	//按照长度分割，最后的0就不会干扰
					thecode[i]=singlecode;
					code=code.substring(codelength[i]);
				}
				else {
					thecode[i]="";
				}
			}
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void DecompressBegin() throws FileNotFoundException {
		int restnumber=0;
		String codecontent="";
		String singlgecodecontent="";
		FileInputStream fis=new FileInputStream(ZipPath);
		FileOutputStream fos=new FileOutputStream(FilePath);
		try {
			while(fis.available()>1) {
				codecontent+=intChangTostring(fis.read());
			}
			restnumber=fis.read();
			codecontent=codecontent.substring(0, codecontent.length()-restnumber);//除去最后补的0
			for(int i=0;i<codecontent.length();i++) {
				singlgecodecontent=codecontent.substring(0,i+1);	//进步值从1递增~
				for(int j=0;j<thecode.length;j++) {					//遍历编码表
					if(thecode[j].equals(singlgecodecontent)) {
						fos.write(j);	//写入
						fos.flush();	
						codecontent=codecontent.substring(i+1);		//截取
						i=-1;	//有相同的，那么下次进步值还是1
						break;
					}
				}
				//如果编码表遍历完毕都没有的话，将进步值不断+1，一定能相等
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private String intChangTostring(int value) {
		String str="";
		for(int i=0;i<8;i++) {
			str=value%2+str;
			value/=2;
		}
		return str;
	}
}
