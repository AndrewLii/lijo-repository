package 文件压缩与解压;

import java.awt.HeadlessException;
import java.io.File;

import javax.swing.JFileChooser;

public class FileChoose {
	public static String InputPath;
	public static String FileName;
	public void getInputPath(){
		int flag=0;
		File file=null;
		JFileChooser filechooser=new JFileChooser();
		try {
			flag=filechooser.showOpenDialog(null);
		}catch(HeadlessException head){
			System.out.println("文件选择器打开失败");
		}
		if(flag==JFileChooser.APPROVE_OPTION) {
			System.out.println("请选择要压缩的文件：");
			file=filechooser.getSelectedFile();
			InputPath=file.getPath();
			FileName=file.getName();
		}
	}
}
