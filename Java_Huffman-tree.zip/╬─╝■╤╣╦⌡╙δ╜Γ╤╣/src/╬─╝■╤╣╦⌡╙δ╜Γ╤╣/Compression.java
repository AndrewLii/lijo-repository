package 文件压缩与解压;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
 
public class Compression {
	private static String  ZipOutputPath;
	private static String CodeOutputPath;
	
	public Compression () {
		String path="C:\\Users\\白马\\Desktop\\";		//压缩文件所在路径设置为桌面
		String zipname=path+FileChoose.FileName+".zip";//路径+文件名+格式
		String datname=path+FileChoose.FileName+".dat";
		File zipfile=new File(zipname);
		File datfile=new File(datname);
		try {
			if(!zipfile.exists()) {		//不存在
				zipfile.createNewFile();	//即创建
			}
			if(!datfile.exists()) {
				datfile.createNewFile();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		ZipOutputPath=zipname;
		CodeOutputPath=datname;
	}
	
	public void compressionBegin(HuffmTree tree) throws Exception {
		String str="";
		String str1="";
		String str2="";
		String code="";
		int index=0;
		int xcode=0;
		int result=0;
		int length=0;
		FileInputStream fis=new FileInputStream(FileChoose.InputPath);
		FileOutputStream fos=new FileOutputStream(ZipOutputPath);
		FileOutputStream fos1=new FileOutputStream(CodeOutputPath);
		
		for(int i=0;i<256;i++) {
			fos1.write(tree.HuffmCode[i].length());			//写入对应哈夫曼编码的长度
			code+=tree.HuffmCode[i];
			fos1.flush();
		}
		System.out.println(code);
		while(code.length()>=8) {							//拆分
			str1=code.substring(0, 8);
			xcode=stringChangtoint(str1);
			fos1.write(xcode);								//写入
			fos1.flush();
			code=code.substring(8);
		}
		length=8-code.length();								//不够补0
		for(int i=0;i<length;i++) {
			code+="0";
		}
		System.out.println(code);
		str1=code.substring(0, 8);
		xcode=stringChangtoint(str1);
		fos1.write(xcode);
		fos1.flush();
		fos1.close();
		
		index=fis.read();				//为什么还要再读一次呢，因为我们获得了相应字符的哈夫曼编码，还需要根据这个文件把对应的哈夫曼编码连接起来
		while(index!=-1) {
			str+=tree.HuffmCode[index];	//链接
			index=fis.read();
		}
		System.out.println(str);
		fis.close();
		while(str.length()>=8) {		//8个一组
			str2=str.substring(0, 8);		//拆分
			result=stringChangtoint(str2);	//换进制
			fos.write(result);			//写入
			fos.flush();				//flush指针
			str=str.substring(8);		//把源文件的前8个已经拆分掉的去掉
		}
		
		length=8-str.length();		//不够8个补0
		for(int i=0;i<length;i++) {
			str+="0";
		}
		//System.out.println(str.length());
		str2=str.substring(0,8);
		result=stringChangtoint(str2);
		fos.write(result);				//写入
		fos.write(length);
		fos.close();
	}
	
	private int stringChangtoint(String s) {
		int v1=(s.charAt(0)-48)*128;  
        int v2=(s.charAt(1)-48)*64;  
        int v3=(s.charAt(2)-48)*32;  
        int v4=(s.charAt(3)-48)*16;  
        int v5=(s.charAt(4)-48)*8;  
        int v6=(s.charAt(5)-48)*4;  
        int v7=(s.charAt(6)-48)*2;  
        int v8=(s.charAt(7)-48)*1; 
        return v1+v2+v3+v4+v5+v6+v7+v8; 
	}
}
