package 文件压缩与解压;

public class Interface {
	Interface(){
		try {
			System.out.println("请选择要压缩的文件：");
			new FileChoose().getInputPath();
			HuffmTree tree=new HuffmTree();
			HuffmNode root=tree.createTree();
			System.out.println("哈夫曼树创建成功~");
			//开始压缩
			System.out.println("开始压缩");
			Compression begin=new Compression();
			begin.compressionBegin(tree);
			System.out.println("压缩完成");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
