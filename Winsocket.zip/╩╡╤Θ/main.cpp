#include <graphics.h>
#include <stdio.h>
#include <process.h>
#include <stdlib.h>
#include <winsock.h>
#include <string.h>
#define IP "172.20.10.2"
#define PORT 15001
#define BUFFER_SIZE 1024
int logo;
int single=0;
SOCKET sin;
WSADATA client;
struct sockaddr_in cos;
char buffer[BUFFER_SIZE];
HANDLE Client_Send= {NULL};
HANDLE Client_Recv= {NULL};
//winsock ����
/*PIMAGE message_list[10];
PIMAGE chat_window;
PIMAGE button[3];*/
//EGE ����
unsigned __stdcall Send(void *param)
{
    printf("���Ѿ�����������\n");
    printf("���û�˽�ģ��������Ӧ�û���\n");
    printf("��ȫ�˳�ϵͳ,�������롰break���˳�˽��,������ ��exit��\n");
    while(1)
    {
        scanf("%s",buffer);
        if(buffer[0]=='e' && buffer[1]=='x' && buffer[2]=='i' && buffer[3]=='t')
        {
            send(sin,buffer,sizeof(buffer),0);
            single=1;
            break;
        }
        else
        {
            if(sizeof(buffer)>BUFFER_SIZE)
            {
                printf("���볬�ޣ���ֶη���...\n");
            }
            else
            {
                send(sin,buffer,sizeof(buffer),0);
            }
        }
    }
    return 0;
};
unsigned __stdcall Recv (void *param)
{
    int len;
    while(1)
    {
        if(single==1)
        {
            break;
        }
        memset(buffer,0,sizeof(buffer));
        recv(sin,buffer,sizeof(buffer),0);
        printf("%s\n",buffer);
        //Sleep(3000);
    }
    return 0;
}
void start_client()
{
    char name[20];
    cos.sin_family=AF_INET;
    cos.sin_port=PORT;
    cos.sin_addr.s_addr=inet_addr(IP);
    if(connect(sin,(struct sockaddr *)&cos,sizeof(cos))==SOCKET_ERROR)
    {
        printf("���ӷ�����ʧ��...\n");
    }
    else
    {
        printf("���ӷ������ɹ�~~~\n");
        printf("�����������û���\n");
        scanf("%s",name);
        send(sin,name,sizeof(name),0);
        Client_Send=(HANDLE)_beginthreadex(NULL,0,Send,NULL,0,NULL);
        Client_Recv=(HANDLE)_beginthreadex(NULL,0,Recv,NULL,0,NULL);
    }
}
int main()
{
    if(WSAStartup(MAKEWORD(2,1),&client)==SOCKET_ERROR)
    {
        printf("��SOCKETʧ��...\n");
        exit(1);
    }
    else
    {
        printf("��SOCKET�ɹ�~~~\n");
        if((sin=socket(AF_INET,SOCK_STREAM,0))==INVALID_SOCKET)
        {
            printf("����SOCKETʧ��...\n");
            exit(1);
        }
        else
        {
            printf("����SOCKET�ɹ�~~~\n");
            start_client();
        }
    }
    while(single==0)
    {
        ;
    }
    //WSACleanup();
    //closesocket(sin);
    return 0;
}

