#include <stdio.h>
#include <windows.h>
int main()
{
    char v[20];
    scanf("%s",v);
    return 0;
}
