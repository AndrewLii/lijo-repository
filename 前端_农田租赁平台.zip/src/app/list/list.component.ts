import { Component, OnInit, AfterViewInit, ElementRef, Renderer2, HostListener} from '@angular/core';
import { trigger, state, style, animate, transition, keyframes } from '@angular/animations';
import { HttpRequestService } from '../http-request.service';
import { ActivatedRoute } from '@angular/router';
import { Kind, Category, Acreage, Price, Sort, Selected } from '../define';
import { Land } from '../define';
import { Crop } from '../define';
import { Evaluation } from '../define';

declare var addressInit: any;
declare var AMap: any;

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
  animations: [
    trigger('inputState', [
      state('inactive', style({ width: '140px' })),
      transition('inactive => active', [
        animate('0.3s ease-out' , keyframes([
          style({width: '140px', offset: 0}),
          style({width: '240px', offset: 0.3}),
          style({width: '220px', offset: 1})
        ]))
      ]),
      state('active', style({width: '220px'})),
      transition('active => inactive', [
        animate('0.3s ease-out', keyframes([
          style({width: '220px', offset: 0}),
          style({width: '120px', offset: 0.3}),
          style({width: '140px', offset: 1})
        ]))
      ])
    ]),
    trigger('moreState', [
      state('inactive', style({ height: '25px' })),
      transition('inactive => active', [
        animate('0.3s ease-out', keyframes([
          style({ height: '25px', offset: 0 }),
          style({ height: '50px', offset: 0.3 }),
          style({ height: 'auto', offset: 1 })
        ]))
      ]),
      state('active', style({ height: 'auto' })),
      transition('active => inactive', [
        animate('0.3s ease-out', keyframes([
          style({ height: 'auto', offset: 0 }),
          style({ height: '50px', offset: 0.3}),
          style({ height: '25px', offset: 1 })
        ]))
      ])
    ])
  ]
})
export class ListComponent implements OnInit, AfterViewInit {

  constructor(private el: ElementRef,
              private renderer: Renderer2,
              private httpService: HttpRequestService,
              private route: ActivatedRoute) {}

  inputstate = 'inactive';

  morestate = 'inactive';

  caidi = require('../../image/caidi.jpg');

  toolBarOffsetHeight = 0;

  LandList: Land[];

  TotalCropList: Crop[];

  EvaluationList: Evaluation[];
  GrainList: Crop[];
  FruitList: Crop[];

  VegetablesList: Crop[];


  Map: any;

  public Kinds: Kind[] = [
    { kindId: '不限类别', kindName: '不限', ifSelected: false },
    { kindId: '蔬菜', kindName: '蔬菜', ifSelected: false },
    { kindId: '粮食', kindName: '粮食', ifSelected: false },
    { kindId: '水果', kindName: '水果', ifSelected: false },
    { kindId: '家禽', kindName: '家禽', ifSelected: false },
    { kindId: '鱼类', kindName: '鱼类', ifSelected: false },
    { kindId: '农副产品', kindName: '农副产品', ifSelected: false }
  ];

  public Categoryes: Category[] = [
    { categoryId: '不限种类', categoryName: '不限', kindId: '不限类别', ifSelected: false },
    { categoryId: '葡萄', categoryName: '葡萄', kindId: '水果', ifSelected: false },
    { categoryId: '百香果', categoryName: '百香果', kindId: '水果', ifSelected: false },
    { categoryId: '香蕉', categoryName: '香蕉', kindId: '水果', ifSelected: false },
    { categoryId: '苹果', categoryName: '苹果', kindId: '水果', ifSelected: false },
    { categoryId: '金桔', categoryName: '金桔', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },
    { categoryId: '山竹', categoryName: '山竹', kindId: '水果', ifSelected: false },

  ];

  public Acreages: Acreage[] = [
    { acreageId: '不限面积', acreageName: '不限', acreageInterval: [-1, -1], ifSelected: false },
    { acreageId: '一亩', acreageName: '0亩-1亩', acreageInterval: [0, 1], ifSelected: false },
    { acreageId: '十亩', acreageName: '1亩-10亩', acreageInterval: [1, 10], ifSelected: false },
    { acreageId: '一百亩', acreageName: '10亩-100亩', acreageInterval: [10, 100], ifSelected: false },
    { acreageId: '五百亩', acreageName: '100亩-500亩', acreageInterval: [100, 500], ifSelected: false },
    { acreageId: '五百亩以上', acreageName: '500亩以上', acreageInterval: [500, -1], ifSelected: false },
  ];

  public Prices: Price[] = [
    { priceId: '不限价格', priceName: '不限', priceInterval: [-1, -1], ifSelected: false },
    { priceId: '一百元', priceName: '0-100', priceInterval: [0, 100], ifSelected: false },
    { priceId: '两百元', priceName: '100-200', priceInterval: [100, 200], ifSelected: false },
    { priceId: '三百元', priceName: '200-300', priceInterval: [200, 300], ifSelected: false },
    { priceId: '四百元', priceName: '300-400', priceInterval: [300, 400], ifSelected: false },
    { priceId: '五百元以上', priceName: '500以上', priceInterval: [500, -1], ifSelected: false },

  ];

  public Sorts: Sort[] = [
    { sortId: '推荐排序', sortName: '推荐排序', ifSelected: false },
    { sortId: '评价最高', sortName: '评价最高', ifSelected: false },
    { sortId: '价格最低', sortName: '价格最低', ifSelected: false },
    { sortId: '价格最高', sortName: '价格最高', ifSelected: false}
  ];

  public TheSelected: Selected = {
    selectedKind: '',
    selectedCategory: [],
    selectedArea: [],
    selectedAcreage: [],
    selectedPrice: [],
    selectedSort: ''
  };

  ngOnInit() {
    const area = new addressInit('cmbProvince', 'cmbCity' , 'cmbArea');
    this.toolBarOffsetHeight = this.el.nativeElement.querySelector('.toolbar-content').offsetTop;
    this.getLandList();
    // 部署到服务器上时，getLandList()替换为reGetLandList()
    // this.reGetLandList();
  }

  ngAfterViewInit() {
    let selectedKindId = null;
    selectedKindId = this.route.snapshot.paramMap.get(`kindId`);

    if (selectedKindId !== null) {
      for (let i = 0; i < this.Kinds.length; i++) {
        if (selectedKindId === this.Kinds[i].kindId) {
          this.onSelectName(this.Kinds[i]);
        }
      }
    }
  }

  getLandList(): void {
    this.httpService.getLandList()
      .subscribe(LandList => this.LandList =  LandList,
        () => console.log('error'),
        () => this.showMap());
  }

  reGetLandList(): void {
    let province = null;
    let city = null;
    let area = null;
    let dom = null;
    let selectedKindId = null;

    selectedKindId = this.route.snapshot.paramMap.get(`kindId`);

    if (selectedKindId !== null) {
      for (let i = 0; i < this.Kinds.length; i++) {
        if (selectedKindId === this.Kinds[i].kindId) {
          this.Kinds[i].ifSelected = true;
        }
      }
    }

    dom = this.el.nativeElement.querySelector('#cmbProvince');
    province = dom.options[dom.selectedIndex].text;
    dom = this.el.nativeElement.querySelector('#cmbCity');
    city = dom.options[dom.selectedIndex].text;
    dom = this.el.nativeElement.querySelector('#cmbArea');
    area = dom.options[dom.selectedIndex].text;

    this.TheSelected.selectedArea[0] = province;
    this.TheSelected.selectedArea[1] = city;
    this.TheSelected.selectedArea[2] = area;

    for (let i = 0; i < this.Kinds.length; i++) {
      if (this.Kinds[i].ifSelected === true) {
        this.TheSelected.selectedKind = this.Kinds[i].kindId;
      }
    }

    for ( let i = 0; i < this.Categoryes.length; i++) {
      if (this.Categoryes[i].ifSelected === true) {
        this.TheSelected.selectedCategory.push(this.Categoryes[i].categoryId);
      }
    }

    for (let i = 0; i < this.Acreages.length; i++) {
      if (this.Acreages[i].ifSelected === true) {
        this.TheSelected.selectedAcreage = this.Acreages[i].acreageInterval;
      }
    }

    for (let i = 0; i < this.Prices.length; i++) {
      if (this.Prices[i].ifSelected === true) {
        this.TheSelected.selectedPrice = this.Prices[i].priceInterval;
      }
    }

    for (let i = 0; i < this.Sorts.length; i++) {
      if (this.Sorts[i].ifSelected === true) {
        this.TheSelected.selectedSort = this.Sorts[i].sortId;
      }
    }

    // alert('Kind:' + this.TheSelected.selectedKind
    // + 'Category:'+ this.TheSelected.selectedCategory
    // + 'Area:' + this.TheSelected.selectedArea
    // + 'Acreage:' + this.TheSelected.selectedAcreage
    // + 'Price:' + this.TheSelected.selectedPrice
    // + 'Sort:' + this.TheSelected.selectedSort);
    this.httpService.reGetLandList(this.TheSelected)
      .subscribe(LandList => this.LandList =  LandList,
        () => console.log('error'),
        () => this.showMap());
  }

  getCategory(id: string): void {
    this.httpService.getCategory(id).subscribe(CategoryContent => this.Categoryes = CategoryContent);
  }

  getCropList(id: string): void {
    this.httpService.getCropList(id)
      .subscribe(CropLists => this.TotalCropList =  CropLists,
        () => console.log('error'),
        () => this.showCropList());

  }

  getEvaluationList(id: string): void {
    this.httpService.getEvaluationList(id)
      .subscribe(EvaluationList => this.EvaluationList = EvaluationList);
  }

  private showCropList(): void {
    this.GrainList = [];
    this.FruitList = [];
    this.VegetablesList = [];

    for (let i = 0; i < this.TotalCropList.length; i++){
      if (this.TotalCropList[i].type === 1){
        this.GrainList.push(this.TotalCropList[i]);
      } else if (this.TotalCropList[i].type === 2) {
        this.VegetablesList.push(this.TotalCropList[i]);
      } else {
        this.FruitList.push(this.TotalCropList[i]);
      }
    }
  }

  private showMap(): void {
    let poiList: any[] = [];
    let lng: number;
    let lat: number;
    const placeSearch = new AMap.PlaceSearch();

    this.Map = new AMap.Map('myMap', {
      resizeEnable: true,
      zoom: 15,
      center: [110.463353, 29.13408]
    });

    const map = this.Map;

    for (let i = 0; i < this.LandList.length; i++) {
      const landname = this.LandList[i].name;
      let marker = null;
      placeSearch.search(this.LandList[i].address, function (status, result) {
        if (status === 'complete' && result.info === 'OK') {
          poiList = result.poiList.pois;
          lng = poiList[0].location.lng;

          lat = poiList[0].location.lat;

          marker = new AMap.Marker({
            position: new AMap.LngLat(lng, lat),
            title: landname
          });

          marker.setLabel({
            offset: new AMap.Pixel(20, 20),
            content: landname
          });

          map.add(marker);
        }
      });
    }
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(event) {
    const scrollHeight = window.scrollY;
    const toolBar = this.el.nativeElement.querySelector('.toolbar-content');
    if (scrollHeight > this.toolBarOffsetHeight - 20) {
      if (scrollHeight > 755 + this.toolBarOffsetHeight) {
        this.renderer.setStyle(toolBar, 'position', 'relative');
        this.renderer.removeClass(toolBar, 'fixed');
        this.renderer.addClass(toolBar, 'on-bottom');
      } else {
        this.renderer.removeClass(toolBar, 'on-bottom');
        this.renderer.setStyle(toolBar, 'position', 'fixed');
        this.renderer.addClass(toolBar, 'fixed');
      }
    } else {
      this.renderer.setStyle(toolBar, 'position', 'relative');
      this.renderer.removeClass(toolBar, 'fixed');
    }
  }

  onSelectName(kind: Kind): void {
    let dom;
    // 通过id选择到的dom元素
    let flag;
    // 此dom元素是否被选中的标志
    const render = this.renderer;

    for (let i = 0; i < this.Kinds.length; i++) {
      dom = this.el.nativeElement.querySelector('#' + this.Kinds[i].kindId);

      if (this.Kinds[i] === kind) {
        flag = dom.classList.contains('selected');
        // 如果此dom元素包含了selected类，则代表被选中了，点击它则代表取消选中，注意这里有个反转
        if (flag === true) {
          render.removeClass(dom, 'selected');
          kind.ifSelected = false;
          // 取消选中
        } else {
          render.addClass(dom, 'selected');
          kind.ifSelected = true;
          // 确定选中
        }
      } else {
        render.removeClass(dom, 'selected');
        this.Kinds[i].ifSelected = false;
      }
    }
    // this.getCategory(kind.kindId);
  }

  onSelectCategory(category: Category): void {
    let dom;
    // 需要操作的dom元素
    let flag;
    // flag为true则代表此元素包含selected类，点击此dom元素则代表取消选中！！！
    const render = this.renderer;
    // this.Kinds[0] 代表不限类别

    if (category === this.Categoryes[0]) {
      dom = this.el.nativeElement.querySelector('#' + category.categoryId);
      flag = dom.classList.contains('selected');

      if (flag === true) {
        render.removeClass(dom, 'selected');
        category.ifSelected = false;
        // 未被选中
      }else {
        render.addClass(dom, 'selected');
        category.ifSelected = true;
        // 被选中
      }

      for (let i = 1; i < this.Categoryes.length; i++){
        dom = this.el.nativeElement.querySelector('#' + this.Categoryes[i].categoryId);
        render.removeClass(dom, 'selected');
        this.Categoryes[i].ifSelected = false;
        // 被选中的为“不限类别”，自然其他选项全部置为未被选中
      }
    } else {
      dom = this.el.nativeElement.querySelector('#' + this.Categoryes[0].categoryId);
      render.removeClass(dom, 'selected');
      this.Categoryes[0].ifSelected = false;

      dom = this.el.nativeElement.querySelector('#' + category.categoryId);
      flag = dom.classList.contains('selected');

      if (flag === true) {
        render.removeClass(dom, 'selected');
        category.ifSelected = false;
      } else {
        render.addClass(dom, 'selected');
        category.ifSelected = true;
      }
    }
  }

  onSelectAcreage(acreage: Acreage) {
    let dom;
    let flag;
    const render = this.renderer;

    for (let i = 0; i < this.Acreages.length; i++) {
      dom = this.el.nativeElement.querySelector('#' + this.Acreages[i].acreageId);

      if (this.Acreages[i] === acreage) {
        flag = dom.classList.contains('selected');
        if (flag === true) {
          render.removeClass(dom, 'selected');
          acreage.ifSelected = false;
        } else {
          render.addClass(dom, 'selected');
          acreage.ifSelected = true;
        }
      } else {
        render.removeClass(dom, 'selected');
        this.Acreages[i].ifSelected = false;
      }
    }
  }

  onSelectPrice(price: Price) {
    let dom;
    let flag;
    const render = this.renderer;

    for (let i = 0; i < this.Prices.length; i++) {
      dom = this.el.nativeElement.querySelector('#' + this.Prices[i].priceId);

      if (this.Prices[i] === price) {
        flag = dom.classList.contains('selected');
        if (flag === true) {
          render.removeClass(dom, 'selected');
          price.ifSelected = false;
        } else {
          render.addClass(dom, 'selected');
          price.ifSelected = true;
        }
      } else {
        render.removeClass(dom, 'selected');
        this.Prices[i].ifSelected = false;
      }
    }
  }

  onSelectSort(sort: Sort) {
    let dom;
    let flag;
    const render = this.renderer;

    for (let i = 0; i < this.Sorts.length; i++) {
      dom = this.el.nativeElement.querySelector('#' + this.Sorts[i].sortId);

      if (this.Sorts[i] === sort) {
        flag = dom.classList.contains('selected');
        if (flag === true) {
          render.removeClass(dom, 'selected');
          sort.ifSelected = false;
        } else {
          render.addClass(dom, 'selected');
          sort.ifSelected = true;
        }
      } else {
        render.removeClass(dom, 'selected');
        this.Sorts[i].ifSelected = false;
      }
    }
  }

  private evaluationView(land: Land): void {
    const myEvaluation = this.el.nativeElement.querySelector('#myEvaluation');
    const myList = this.el.nativeElement.querySelector('#myList');
    const myMap = this.el.nativeElement.querySelector('#myMap');
    this.renderer.setStyle(myList, 'display', 'none');
    this.renderer.setStyle(myMap, 'display', 'none');
    this.renderer.setStyle(myEvaluation, 'display', 'block');

    this.getEvaluationList(land.id);
  }

  private listView(land: Land): void {
    const myList = this.el.nativeElement.querySelector('#myList');
    const myMap = this.el.nativeElement.querySelector('#myMap');
    const myEvaluation = this.el.nativeElement.querySelector('#myEvaluation');
    this.renderer.setStyle(myEvaluation, 'display', 'none');
    this.renderer.setStyle(myMap, 'display', 'none');
    this.renderer.setStyle(myList, 'display', 'block');

    this.getCropList(land.id);
  }

  private mapView(): void {
    const myMap = this.el.nativeElement.querySelector('#myMap');
    const myList = this.el.nativeElement.querySelector('#myList');
    const myEvaluation = this.el.nativeElement.querySelector('#myEvaluation');
    this.renderer.setStyle(myList, 'display', 'none');
    this.renderer.setStyle(myEvaluation, 'display', 'none');
    this.renderer.setStyle(myMap, 'display', 'block');
  }

  private inputchange(): void {
    this.inputstate = this.inputstate === 'active' ? 'inactive' : 'active';
  }

  private moreClick(): void {
    this.morestate = this.morestate === 'active' ? 'inactive' : 'active';
  }

}
