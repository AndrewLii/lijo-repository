import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settlement',
  templateUrl: './settlement.component.html',
  styleUrls: ['./settlement.component.css']
})
export class SettlementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
