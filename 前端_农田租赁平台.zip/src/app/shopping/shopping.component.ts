import { Component, OnInit, ElementRef, Renderer2 } from '@angular/core';
import { animate, keyframes, state, style, transition, trigger } from '@angular/animations';
import { Land } from '../define';
import { HttpRequestService } from '../http-request.service';
import { Crop } from '../define';
import { GeneralServiceService } from '../general-service.service';
import { User } from '../define';
import { Order } from '../define';
import { OrderCount } from '../define';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.css'],
  animations: [
    trigger('inputState', [
      state('inactive', style({ width: '140px' })),
      transition('inactive => active', [
        animate('0.3s ease-out' , keyframes([
          style({width: '140px', offset: 0}),
          style({width: '240px', offset: 0.3}),
          style({width: '220px', offset: 1})
        ]))
      ]),
      state('active', style({width: '220px'})),
      transition('active => inactive', [
        animate('0.3s ease-out', keyframes([
          style({width: '220px', offset: 0}),
          style({width: '120px', offset: 0.3}),
          style({width: '140px', offset: 1})
        ]))
      ])
    ])
  ]
})
export class ShoppingComponent implements OnInit {

  constructor(private httpService: HttpRequestService,
              private render: Renderer2,
              private el: ElementRef,
              private generalService: GeneralServiceService) { }

  public usericon = require('../../icon/user.png');
  public caidi = require('../../image/caidi.jpg');
  public lanmeiimg = require('../../icon/fruiticon/lanmei.png');

  public inputstate = 'inactive';

  public User: User;
  public LandList: Land[];
  public Orders: Order[];
  public CropList: Crop[] = [
    {id: '1', type: 2, name: '土豆', price: 10, img: require('../../icon/fruiticon/lanmei.png'), amount: 0},
    {id: '2', type: 2, name: '冬瓜', price: 5, img: require('../../icon/fruiticon/lanmei.png'), amount: 1},
    {id: '3', type: 1, name: '小麦', price: 7, img: require('../../icon/fruiticon/lanmei.png'), amount: 0},
    {id: '4', type: 1, name: '水稻', price: 3.5, img: require('../../icon/fruiticon/lanmei.png'), amount: 5},
    {id: '5', type: 3, name: '葡萄', price: 20, img: require('../../icon/fruiticon/lanmei.png'), amount: 0},
    {id: '6', type: 3, name: '桃子', price: 2, img: require('../../icon/fruiticon/lanmei.png'), amount: 3}
  ];

  ngOnInit() {
    this.getLandList();

    // this.getOrders();
  }

  private setCounters(): void {
    for (let i = 0; i < this.LandList.length; i++) {
      this.LandList[i].counter = new OrderCount(this.LandList[i].minDuration, this.LandList[i].minArea, this.LandList[i].price, 0, 0, 0);

      for (let j = 0; j < this.CropList.length; j++) {
        if (this.CropList[j].amount !== 0) {
          this.LandList[i].counter.cropNum++;
          this.LandList[i].counter.cropPrice += this.CropList[j].amount * this.CropList[j].price;
        }
      }

      this.LandList[i].counter.totalPrice = this.LandList[i].counter.landArea * this.LandList[i].counter.landDuration * this.LandList[i].counter.landBasicPrice + this.LandList[i].counter.cropPrice;
    }
  }

  getLandList(): void {
    this.httpService.getLandList()
      .subscribe(
        LandList => this.LandList =  LandList,
        () => alert('erre'),
        () => this.setCounters());

    /*
    let orderIds: string[] = [];
    for (let i = 0; i < this.Orders.length; i++) {
      orderIds.push(this.Orders[i].orderId);
    }
    this.httpService.getLandListByOrderId(orderIds).subscribe(landlist => this.LandList = landlist);
    */
  }

  private getOrders(): void {
    this.User = this.generalService.userGetter();
    this.httpService.getOrders(this.User.phone).subscribe(
        orderlist => this.Orders = orderlist,
        () => alert('error'),
        () => this.getLandList()
      );
  }
  


  private inputchange(): void {
    this.inputstate = this.inputstate === 'active' ? 'inactive' : 'active';
  }

  public durationReduceOne(land: Land): void {
    if (land.counter.landDuration > land.minDuration) {
      land.counter.landDuration--;
    }
    // 接上数据之后html和ts当中的操作值该为但订单中的预定时间,并加上一些值的判断操作
  }

  public durationAddOne(land: Land): void {
    if (land.counter.landDuration < land.duration) {
      land.counter.landDuration++;
    }
    // 接上数据之后html和ts当中的操作值该为但订单中的预定时间
  }

  public areaReduceOne(land: Land): void {
    console.log(land.counter.landArea + 'sss' + land.minArea);
    if (land.counter.landArea > land.minArea) {
      land.counter.landArea--;
      console.log('ssssss');
    }
    // 接上数据之后html和ts当中的操作值该为但订单中的预定面积
  }

  public areaAddOne(land: Land): void {
    if (land.counter.landArea < land.area) {
      land.counter.landArea++;
    }
    // 接上数据之后html和ts当中的操作值该为但订单中的预定面积
  }

  public cropReduceOne(crop: Crop, land: Land): void {
    if (crop.amount >= 1){
      crop.amount--;

      if (crop.amount === 0){
        land.counter.cropNum--;
      }
    }
  }

  public cropAddOne(crop: Crop, land: Land): void {
    if (crop.amount === 0) {
      land.counter.cropNum++;
    }
    crop.amount++;
  }

}
