import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Land } from './define';
import { Crop } from './define';

export class FakeServiceService implements InMemoryDbService{

  createDb() {
    const LandList: Land[] = [
      {id: '1001', name: '1号水田', address: '湖南省张家界市吉首大学', label: '旱田', area: 10, minArea: 1, duration: 10, minDuration: 1, price: 300, counter: null},
      {id: '1002', name: '2号水田', address: '湖南省张家界市吉首大学张家界校区北门', label: '旱田', area: 10, minArea: 1, duration: 10, minDuration: 1, price: 300, counter: null},
      {id: '1003', name: '3号水田', address: '湖南省张家界市吉首大学张家界校区南门', label: '旱田', area: 10, minArea: 1, duration: 10, minDuration: 1, price: 300, counter: null},
      {id: '1004', name: '4号水田', address: '湖南省张家界市人之初幼儿园', label: '旱田', area: 10, minArea: 1, duration: 10, minDuration: 1, price: 300, counter: null},
      {id: '1005', name: '5号水田', address: '湖南省张家界市华都国际花园', label: '旱田', area: 10, minArea: 1, duration: 10, minDuration: 1, price: 300, counter: null},
      {id: '1006', name: '6号水田', address: '湖南省张家界市吉首大学张家界校区逸夫楼', label: '旱田', area: 10, minArea: 1, duration: 10, minDuration: 1, price: 300, counter: null}
    ];

    return {LandList};
  }
}

export class CropServiceService implements InMemoryDbService{

  createDb() {
    const CropLists: Crop[] = [
      {id: '1', type: 2, name: '土豆', price: 10, img: 'unknown', amount: 0},
      {id: '2', type: 2, name: '冬瓜', price: 5, img: 'unknown', amount: 0},
      {id: '3', type: 1, name: '小麦', price: 7, img: 'unknown', amount: 0},
      {id: '4', type: 1, name: '水稻', price: 3.5, img: 'unknown', amount: 0},
      {id: '5', type: 3, name: '葡萄', price: 20, img: 'unknown', amount: 0},
      {id: '6', type: 3, name: '桃子', price: 2, img: 'unknown', amount: 0}
    ];
    return {CropLists};
  }

}
