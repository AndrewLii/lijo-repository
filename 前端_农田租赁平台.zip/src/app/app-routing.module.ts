import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisteredComponent } from './registered/registered.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ListComponent } from './list/list.component';
import { ShoppingComponent } from './shopping/shopping.component';

const routes: Routes = [
  {path: 'registered', component: LoginComponent},
  // 登陆组件是registered ，注册组件是login，写反了，不改了
  {path: 'login', component: RegisteredComponent},
  // 这个才是登陆组件
  {path: 'homepage', component: HomepageComponent},
  // 主页
  {path: 'list', component: ListComponent},
  // 列表页面
  {path: 'list/:kindId', component: ListComponent},
  // 从主页选择作物种类的列表页面
  { path: 'shoppingcart', component: ShoppingComponent },
  // 购物车页面
  { path: '', redirectTo: '/homepage', pathMatch: 'full' }
  // 默认路由
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {

}
