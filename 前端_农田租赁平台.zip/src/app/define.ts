export class User {
  constructor(
    public id: string,
    public name: string,
    public password: string,
    public phone: string,
    public hometown?: string,
    public address?: string,
  ) {}
}

export class Land {
  constructor(
    public id: string, // 土地id
    public name: string,  // 土地名称
    public address: string, // 土地地址
    public label: string, //  土地标签
    public area: number, // 土地面积
    public minArea: number, // 最小租赁面积
    public duration: number,  // 租赁时间
    public minDuration: number, // 最短租赁时间
    public price: number, // 土地单位价格
    public counter: OrderCount // 土地价格计算器
  ) {}
}

export class Crop {
  constructor(
    public id: string,
    public type: number,
    public name: string,
    public price: number,
    public img: string,
    public amount: number
  ) {}
}

export class News {
  constructor(
    public title: string,
    public content: string,
    public date: string,
    public hot: number,
    public views: number,
    public evaluation: number
  ) {}
}

export class Evaluation {
  constructor(
    public name: string,
    public avatar: string,
    public content: string,
    public imgUrls?: string[]
  ) {}
}

export class Kind {
  // 作物种类，例如：蔬菜，提供id以供database查询其拥有的作物种类
  constructor(
    public kindId: string,
    // 作物类别id
    public kindName: string,
    // 作物类别名称
    public ifSelected: boolean
    // 是否被选中
    ) {}
}

export class Category {
  // 作物类别，例如：土豆，提供id以供查询符合条件的土地，name以供展示，id以供区分不同的作物所属的作物种类
  constructor(
    public categoryId: string,
    // 作物种类id
    public categoryName: string,
    // 作物种类名称
    public kindId: string,
    // 作物种类所属类别id
    public ifSelected: boolean
    // 是否被选中
  ) {}
}

export class Acreage {
  // 面积区间，面积，提供id以供组件选择，提供name以供展示，提供Interval（面积区间）以供database查询
  constructor(
    public acreageId: string,
    // 面积id
    public acreageName: string,
    // 面积名称
    public acreageInterval: number[],
    // 面积区间，0：最小面积，1：最大面积
    public ifSelected: boolean
    // 是否被选中
  ) {}
}

export class Price {
  // 价格区间，价格，提供id以供组件选择，提供name以供组件展示，提供Interval（价格区间）以供database查询
  constructor(
    public priceId: string,
    // 价格id
    public priceName: string,
    // 价格名称
    public priceInterval: number[],
    // 价格区间，0：最低价格，1：最高价格
    public ifSelected: boolean
    // 是否被选中
  ) {}
}

export class Sort {
  // 排序，默认排序，只是排序，对back-end返回的列表有作用
  constructor(
    public sortId: string,
    // 排序id
    public sortName: string,
    // 排序名称
    public ifSelected: boolean
    // 是否被选中
  ) {}
}

export class Selected {
  // 筛选条件汇总
  constructor(
    public selectedKind: string,
    // 选中的作物类别,字符数组，
    public selectedCategory: string[],
    // 选中的作物种类，字符数组，可以多选
    public selectedArea: string[],
    // 选中的地区，0-2：省，市，区
    public selectedAcreage: number[],
    // 选中的面积,0:最小面积,1:最大面积
    public selectedPrice: number[],
    // 选中的单位价格,0:最低价格，1：最高价格
    public selectedSort: string
    // 选中的排序方式
  ) {}
}

export class Order {
  // 订单
  constructor(
    public orderId: string,
    // 订单id
    public userId: string,
    // 用户id
    public landId: string,
    // 土地id
    public cropList: Crop[],
    // 用户选择的作物列表
    public orderState: string,
    // 订单状态
    public orderInfo: string[],
    // 订单详情
    public imgs: string[],
    // 订单详情中的图片
  ) {}
}

export class OrderCount {
  // 订单总价计算
  constructor(
    public landDuration: number,
    // 订单土地的的租赁时间
    public landArea: number,
    // 订单土地的租赁面积,
    public landBasicPrice: number,
    // 订单土地的基础价格
    public cropNum: number,
    // 订单选择的作物数量
    public cropPrice: number,
    // 订单选择的作物的总价格
    public totalPrice: number
    // 订单总价
  ){}
}
