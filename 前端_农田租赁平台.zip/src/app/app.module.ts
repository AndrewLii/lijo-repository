import { BrowserModule } from '@angular/platform-browser';
import { NgModule} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisteredComponent } from './registered/registered.component';
import { AppRoutingModule } from './app-routing.module';
import { HomepageComponent } from './homepage/homepage.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpRequestService } from './http-request.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { FakeServiceService } from './fake-service.service';
import { ListComponent } from './list/list.component';
import { ShoppingComponent } from './shopping/shopping.component';
import { GeneralServiceService } from './general-service.service';
import { SettlementComponent } from './settlement/settlement.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisteredComponent,
    HomepageComponent,
    ListComponent,
    ShoppingComponent,
    SettlementComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    HttpClientInMemoryWebApiModule.forRoot(FakeServiceService, {dataEncapsulation: false})
  ],
  providers: [HttpRequestService, GeneralServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
