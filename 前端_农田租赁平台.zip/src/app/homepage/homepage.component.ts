import { Component, OnInit , ElementRef , Renderer2, HostListener} from '@angular/core';
import { trigger, state, style, animate, transition, keyframes, animation } from '@angular/animations';
import { HttpRequestService } from '../http-request.service';
import { Land } from '../define';
import { Crop } from '../define';
import { Evaluation } from '../define';
import { News } from '../define';
import { Kind } from '../define';
import { Router } from '@angular/router';
import { GeneralServiceService } from '../general-service.service';

declare  var AMap: any;

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css'],
  animations: [
    trigger('inputState', [
      state('inactive', style({ width: '140px' })),
      transition('inactive => active', [
        animate('0.3s ease-out' , keyframes([
          style({width: '140px', offset: 0}),
          style({width: '240px', offset: 0.3}),
          style({width: '220px', offset: 1})
        ]))
      ]),
      state('active', style({width: '220px'})),
      transition('active => inactive', [
        animate('0.3s ease-out', keyframes([
          style({width: '220px', offset: 0}),
          style({width: '120px', offset: 0.3}),
          style({width: '140px', offset: 1})
        ]))
      ])
    ]),
    trigger('buttonState', [
      state('inactive', style({ opacity: 0})),
      state('active', style({ opacity: 1})),
      transition('inactive <=> active', animate(300))
    ]),
    trigger('menuState', [
      state('inactive', style({ height: '0' })),
      state('active', style( { height: '250px' })),
      transition('inactive <=> active', animate('0.3s ease-out'))
    ])
  ]
})

export class HomepageComponent implements OnInit {

  LandList: Land[];

  TotalCropList: Crop[];

  EvaluationList: Evaluation[];

  NewsList: News[];

  GrainList: Crop[];
  FruitList: Crop[];
  VegetablesList: Crop[];

  public Kinds: Kind[] = [
    { kindId: '不限类别', kindName: '不限', ifSelected: false },
    { kindId: '蔬菜', kindName: '蔬菜', ifSelected: false },
    { kindId: '粮食', kindName: '粮食', ifSelected: false },
    { kindId: '水果', kindName: '水果', ifSelected: false },
    { kindId: '家禽', kindName: '家禽', ifSelected: false },
    { kindId: '鱼类', kindName: '鱼类', ifSelected: false },
    { kindId: '农副产品', kindName: '农副产品', ifSelected: false }
  ];

  Map: any;

  logo = require('../../icon/round_check.png');

  p1 = require('../../image/1.png');
  p2 = require('../../image/2.png');
  p3 = require('../../image/3.png');
  p4 = require('../../image/4.jpg');
  p5 = require('../../image/5.jpg');
  p6 = require('../../image/6.jpg');
  p7 = require('../../image/7.jpg');

  usericon = require('../../icon/user.png');

  cropicon = require('../../icon/crop.png');
  eggsicon = require('../../icon/eggs.png');
  fishsicon = require('../../icon/fishs.png');
  fruiticon = require('../../icon/fruit.png');
  poultryicon = require('../../icon/poultry.png');
  vegetablesicon = require('../../icon/vegetables.png');

  prvebut = require('../../icon/left.png');
  nextbut = require('../../icon/right.png');

  viewsicon = require('../../icon/views.png');
  hoticon = require('../../icon/hot.png');
  communityicon = require('../../icon/community.png');
  timeicon = require('../../icon/time.png');

  caidi = require('../../image/caidi.jpg');
  news = require('../../image/news.png');

  inputstate = 'inactive';
  buttonstate = 'inactive';
  menustate = 'inactive';

  cArr: string[] = ['p7', 'p6', 'p5', 'p4', 'p3', 'p2', 'p1'];

  private timer = setInterval(() => { this.nextimg(); }, 4000);

  toolBarOffsetHeight = 0;

  constructor(private el: ElementRef, private renderer: Renderer2, private httpService: HttpRequestService, private router: Router, private generalService: GeneralServiceService) { }



  ngOnInit() {
    this.getLandList();
    this.getNewsList();
    this.toolBarOffsetHeight = this.el.nativeElement.querySelector('.toolbar-content').offsetTop;
  }

  getLandList(): void {
    this.httpService.getLandList()
      .subscribe(LandList => this.LandList =  LandList,
        () => console.log('error'),
        () => this.showMap());
  }

  getCropList(id: string): void {
    this.httpService.getCropList(id)
      .subscribe(CropLists => this.TotalCropList =  CropLists,
        () => console.log('error'),
        () => this.showCropList());

  }

  getEvaluationList(id: string): void {
    this.httpService.getEvaluationList(id)
      .subscribe(EvaluationList => this.EvaluationList = EvaluationList);
  }

  getNewsList(): void {
    this.httpService.getNewsList()
      .subscribe(NewsList => this.NewsList = NewsList);
  }

  private showCropList(): void {
    this.GrainList = [];
    this.FruitList = [];
    this.VegetablesList = [];

    for (let i = 0; i < this.TotalCropList.length; i++){
      if (this.TotalCropList[i].type === 1){
        // 判断此种作物属于哪种类型
        this.GrainList.push(this.TotalCropList[i]);
      } else if (this.TotalCropList[i].type === 2) {
        this.VegetablesList.push(this.TotalCropList[i]);
      } else {
        this.FruitList.push(this.TotalCropList[i]);
      }
    }
  }

  private showMap(): void {
    let poiList: any[] = [];
    let lng: number;
    let lat: number;
    const placeSearch = new AMap.PlaceSearch();

    this.Map = new AMap.Map('myMap', {
      resizeEnable: true,
      zoom: 15,
      center: [110.463353, 29.13408]
    });

    const map = this.Map;

    for (let i = 0; i < this.LandList.length; i++) {
      const landname = this.LandList[i].name;
      let marker = null;
      placeSearch.search(this.LandList[i].address, function (status, result) {
        if (status === 'complete' && result.info === 'OK') {
          poiList = result.poiList.pois;
          lng = poiList[0].location.lng;

          lat = poiList[0].location.lat;

          marker = new AMap.Marker({
            position: new AMap.LngLat(lng, lat),
            title: landname
          });

          marker.setLabel({
            offset: new AMap.Pixel(20, 20),
            content: landname
          });

          map.add(marker);
        }
      });
    }
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(event) {
    const scrollHeight = window.scrollY;
    const toolBar = this.el.nativeElement.querySelector('.toolbar-content');
    if (scrollHeight > this.toolBarOffsetHeight - 20) {
      if (scrollHeight > 755 + this.toolBarOffsetHeight) {
        this.renderer.setStyle(toolBar, 'position', 'relative');
        this.renderer.removeClass(toolBar, 'fixed');
        this.renderer.addClass(toolBar, 'on-bottom');
      } else {
        this.renderer.removeClass(toolBar, 'on-bottom');
        this.renderer.setStyle(toolBar, 'position', 'fixed');
        this.renderer.addClass(toolBar, 'fixed');
      }
    } else {
      this.renderer.setStyle(toolBar, 'position', 'relative');
      this.renderer.removeClass(toolBar, 'fixed');
    }
  }

  private inputchange(): void {
    this.inputstate = this.inputstate === 'active' ? 'inactive' : 'active';
  }

  private buttonover(): void {
    clearInterval(this.timer);
    this.buttonstate = this.buttonstate === 'inactive' ? 'active' : 'inactive';
  }

  private buttonleave(): void {
    this.timer = setInterval(() => { this.nextimg(); }, 4000);
    this.buttonstate = this.buttonstate === 'inactive' ? 'active' : 'inactive';
  }

  private buttonshow(): void {
    const button = this.el.nativeElement.querySelector('.btn');
  }

  private previmg(): void {
    const libox = this.el.nativeElement.querySelector('#image-box');
    const totalli = libox.querySelectorAll('li');

    for (let i = 0; i < totalli.length; i++){
      this.renderer.removeClass(totalli[i], this.cArr[i]);
    }

    this.cArr.unshift(this.cArr[6]);
    this.cArr.pop();

    for (let i = 0; i < totalli.length; i++){
      this.renderer.addClass(totalli[i], this.cArr[i]);
    }
  }

  private nextimg(): void {
    const libox = this.el.nativeElement.querySelector('#image-box');
    const totalli = libox.querySelectorAll('li');

    for (let i = 0; i < totalli.length ; i++){
      this.renderer.removeClass(totalli[i], this.cArr[i]);
    }

    this.cArr.push(this.cArr[0]);
    this.cArr.shift();

    for (let i = 0; i < totalli.length; i++){
      this.renderer.addClass(totalli[i], this.cArr[i]);
    }
  }

  private evaluationView(event: Event, land: Land): void {
    const myEvaluation = this.el.nativeElement.querySelector('#myEvaluation');
    const myList = this.el.nativeElement.querySelector('#myList');
    const myMap = this.el.nativeElement.querySelector('#myMap');
    this.renderer.setStyle(myList, 'display', 'none');
    this.renderer.setStyle(myMap, 'display', 'none');
    this.renderer.setStyle(myEvaluation, 'display', 'block');

    event.stopPropagation();
    // 阻止事件冒泡

    this.getEvaluationList(land.id);
  }

  private listView(event: Event, land: Land): void {
    const myList = this.el.nativeElement.querySelector('#myList');
    const myMap = this.el.nativeElement.querySelector('#myMap');
    const myEvaluation = this.el.nativeElement.querySelector('#myEvaluation');
    this.renderer.setStyle(myEvaluation, 'display', 'none');
    this.renderer.setStyle(myMap, 'display', 'none');
    this.renderer.setStyle(myList, 'display', 'block');

    event.stopPropagation();

    this.getCropList(land.id);
  }

  private mapView(event: Event): void {
    const myMap = this.el.nativeElement.querySelector('#myMap');
    const myList = this.el.nativeElement.querySelector('#myList');
    const myEvaluation = this.el.nativeElement.querySelector('#myEvaluation');
    this.renderer.setStyle(myList, 'display', 'none');
    this.renderer.setStyle(myEvaluation, 'display', 'none');
    this.renderer.setStyle(myMap, 'display', 'block');

    event.stopPropagation();
  }

  private ifLogincheck(): void {
    if (this.generalService.userGetter() === null) {
      this.showMenu();
      // this.router.navigate(['/login']);
    } else {
      this.showMenu();
    }
  }

  private showMenu(): void {
    this.menustate = this.menustate === 'active' ? 'inactive' : 'active';
  }
}

