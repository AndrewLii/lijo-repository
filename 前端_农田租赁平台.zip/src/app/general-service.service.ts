import { Injectable } from '@angular/core';
import { User} from './define';
import { HttpRequestService } from './http-request.service';

@Injectable({
  providedIn: 'root'
})
export class GeneralServiceService {

  constructor(public httpService: HttpRequestService) { }

  public OneUser: User = null;

  // 获取用户对象
  public getUser(phone: string, password: string): void {
    this.httpService.getUser(phone, password)
      .subscribe(
        (user: any) => this.OneUser = user,
        () => console.log('something is wrong'),
        () => console.log('good')
        );
  }

  // 发送用户对象
  public sendUser(user: User): void {
    this.httpService.sendUser(user);
  }

  // 检查手机是否已经在数据库中
  public checkUserPhone(phone: string): void {
    this.httpService.checkUserPhone(phone);
  }

  public userGetter(): User {
      return this.OneUser;
  }

}
