import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { Land } from './define';
import { Evaluation } from './define';
import { Crop } from './define';
import { News } from './define';
import { User } from './define';
import { Category, Selected, Order } from './define';

const httpOptions = { headers: new HttpHeaders({'Content-Type': 'application/json'})};

// 从这行开始到空行是与用户有关的接口
const getUserServiceUrl = 'api/User';
// 获取用户对象
const sendUserServiceUel = 'api/User';
// 发送用户对象
const checkUserPhone = 'api/User';
// 检查手机是否被注册过

// 从这行开始到空行之间是一些通用接口
const LandServiceUrl = 'api/LandList';
// 获取土地列表接口
const CropServiceUrl = 'api/CropLists';
// 根据土地id获取可种植作物列表接口
const EvaluationServiceUrl = 'api/Evaluation';
// 根据土地id获取该土地评价列表接口
const NewsServiceUrl = 'api/News';
// 获取新闻列表接口

// 从这行到空行之间是list页面专门的根据筛选条件查询数据的接口
const reLandServiceUrl = 'api/reLandList';
// list页面根据筛选条件获取土地列表接口
const CategoryUrl = 'api/Category';
// list页面根据筛选条件获取作物种类列表

// 从这行到空行之间是获取用户订单需要的接口
const orderServiceUrl = 'api/Orders';
// 根据用户id获取用户拥有的订单
const getLandListByOrderIdServiceUrl = 'api/Order';

@Injectable({
  providedIn: 'root'
})

export class HttpRequestService {

  constructor(private http: HttpClient) { }

  getUser(phone: string, password: string): Observable<User> {
    return this.http.post<User>(getUserServiceUrl, {phone, password}, httpOptions);
  }

  sendUser(user: User): void {
    this.http.post<User>(sendUserServiceUel, user, httpOptions);
  }

  checkUserPhone(phone: string): void {
    this.http.post(checkUserPhone, phone, httpOptions);
  }

  getCategory(id: string): Observable<Category[]> {
    return this.http.post<Category[]>(CategoryUrl, id, httpOptions).pipe(
      catchError(this.handleError('getCategory', []))
    );
  }

  getNewsList(): Observable<News[]> {
    return this.http.get<News[]>(NewsServiceUrl).pipe(
      catchError(this.handleError('getNewsList', []))
    );
  }

  getLandList(): Observable<Land[]> {
    return this.http.get<Land[]>(LandServiceUrl).pipe(
      catchError(this.handleError('getLandList', []))
    );
  }

  reGetLandList(selected: Selected): Observable<Land[]> {
    return this.http.post<Land[]>(reLandServiceUrl, selected, httpOptions).pipe(
      catchError(this.handleError('reGetLandList', []))
    );
  }

  getCropList(id: String): Observable<Crop[]> {
    return this.http.post<Crop[]>(CropServiceUrl, id, httpOptions).pipe(
    catchError(this.handleError('getCropList', []))
    );
  }
  // 还需要土地类型

  getEvaluationList(id: string): Observable<Evaluation[]> {
    return this.http.post<Evaluation[]>(EvaluationServiceUrl, id, httpOptions).pipe(
      catchError(this.handleError('getEvaluationList', []))
    );
  }

  getOrders(id: string): Observable<Order[]> {
    return this.http.post<Order[]>(orderServiceUrl, id, httpOptions).pipe(
      catchError(this.handleError('getOrderList', []))
    );
  }

  getLandListByOrderId(ids: string[]): Observable<Land[]> {
    return this.http.post<Land[]>(getLandListByOrderIdServiceUrl, ids , httpOptions).pipe(
      catchError(this.handleError('getLandListByOrderId', []))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      return of(result as T);
    };
  }
}
