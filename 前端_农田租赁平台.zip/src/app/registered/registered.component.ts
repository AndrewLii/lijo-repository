



// !!! 注意，这是登陆组件，脑残把登陆和注册组件的代码写反了:(




import { Component, OnInit , ElementRef , Renderer2} from '@angular/core';
import {User} from '../define';
import { GeneralServiceService } from '../general-service.service';

@Component({
  selector: 'app-registered',
  templateUrl: './registered.component.html',
  styleUrls: ['./registered.component.css']
})
export class RegisteredComponent implements OnInit {
  constructor(private el: ElementRef, private renderer: Renderer2, private generalService: GeneralServiceService) { }

  warnicon = require('../../icon/warn.png');

  warnmessage = '账户、密码不能为空';
  warnmessage1 = '密码错误';

  truepassword = null;
  submitif = false;

  public model = new User(null, null, null, null, null, null);

  ngOnInit() {
    this.setSonHeight();
  }

  onSubmit(): void {
    this.phonecheck();
    if (this.submitif === true){
        this.passwordcheck();
        if (this.submitif === true){
           // this.generalService.getUser(this.model.phone, this.model.password);
        }
    }
  }

  setSonHeight(): void {
    const son = this.el.nativeElement.querySelector('#login-text-filed');
    const fatherHeight = this.el.nativeElement.querySelector('#login-window').offsetHeight;
    const sonHeight = this.el.nativeElement.querySelector('#login-text-filed').offsetHeight;
    const margin = ((fatherHeight - sonHeight) / 2) - 40  + 'px';
    this.renderer.setStyle(son, 'margin-top', margin);
  }

  passwordcheck(): void {
    const password = this.model.password;
    const passwordbox = this.el.nativeElement.querySelector('#password-box');
    const passwordwarn = this.el.nativeElement.querySelector('#password-box-warning');

    if (password !== null){
      if (password === this.truepassword){
        // 密码检查通过
        this.submitif = true;
        this.renderer.removeClass(passwordbox, 'checknotpass');
        this.renderer.addClass(passwordbox, 'checkpass');
        this.renderer.setStyle(passwordwarn, 'display', 'none');

      } else {
        this.submitif = false;
        this.renderer.addClass(passwordbox, 'checknotpass');
        this.renderer.setStyle(passwordwarn, 'display', 'block');
      }
    }else {
      this.submitif = false;
      this.renderer.addClass(passwordbox, 'checknotpass');
      this.renderer.setStyle(passwordwarn, 'display', 'block');
    }

  }

  phonecheck(): void {
    const phonebox = this.el.nativeElement.querySelector('#phone-number-box');
    const phonewarn = this.el.nativeElement.querySelector('#phone-box-warning');
    const phone = this.model.phone;
    const truephone = '15274457466';
    if (this.model.phone != null) {
      /*
        手机号检查通过
          查询数据库有无此账号
            A:如果没有此账号，显示warnmessage
            B：如果有此账号，读取密码
       */
      if (phone === truephone){
        this.submitif = true;
        this.renderer.removeClass(phonebox, 'checknotpass');
        this.renderer.addClass(phonebox, 'checkpass');
        this.renderer.setStyle(phonewarn, 'display', 'none');

        this.truepassword = '1234';

      }else {
       this.submitif = false;
       this.renderer.addClass(phonebox, 'checknotpass');
       this.warnmessage = '账号错误';
       this.renderer.setStyle(phonewarn, 'display', 'block');
      }
    } else {
      this.submitif = false;
      this.renderer.addClass(phonebox, 'checknotpass');
      this.renderer.setStyle(phonewarn, 'display', 'block');
    }
  }

}
