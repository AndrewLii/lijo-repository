



// ！！！ 注意，这是注册组件，脑残把登陆和注册组件的代码写反了:(




import { Component, OnInit , ElementRef , Renderer2} from '@angular/core';
import { User } from '../define';
import { GeneralServiceService } from '../general-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private el: ElementRef, private renderer: Renderer2, private generalService: GeneralServiceService) { }

  warnicon = require('../../icon/warn.png');
  identifier = require('../../image/login-check.png');

  warnmessage = '手机号不能为空';
  warnmessage1 = '验证码错误';
  warnmessage2 = '用户名不能超过10位且不能为空';
  warnmessage3 = '密码不一致';

  trueidentifier = '2616';
  truesms = '1234';
  truepsssword = '84542599';

  submitif = false;

  model = new User(null, null, null, null, null, null);

  ngOnInit() {
    this.setSonHeight();
  }

  onSubmit(): void {
    this.phonecheck();
    if (this.submitif === true){
      this.identifiercheck();
      if (this.submitif === true){
        this.smscheck();
        if (this.submitif === true){
          this.passwordcheck();
          if (this.submitif === true){
            alert('OK');
            // this.generalService.sendUser(this.model);
            // 将注册的用户发送给接口
          }
        }
      }
    }

  }

  setSonHeight(): void {
    const son = this.el.nativeElement.querySelector('#login-text-filed');
    const fatherHeight = this.el.nativeElement.querySelector('#login-window').offsetHeight;
    const sonHeight = this.el.nativeElement.querySelector('#login-text-filed').offsetHeight;
    const margin = ((fatherHeight - sonHeight) / 2) - 40  + 'px';
    this.renderer.setStyle(son, 'margin-top', margin);
  }

  passwordcheck(): void {
      const password = this.model.password;
      const passwordr = this.truepsssword;
      const passwordbox = this.el.nativeElement.querySelector('#password-box');
      const passwordrbox = this.el.nativeElement.querySelector('#password-recheck-box');
      const passwordrwarn = this.el.nativeElement.querySelector('#password-box-warning');

      if (password === passwordr){
        // 密码检查通过
        this.submitif = true;
        this.renderer.removeClass(passwordrbox, 'checknotpass');
        this.renderer.addClass(passwordrbox, 'checkpass');
        this.renderer.addClass(passwordbox, 'checkpass');
        this.renderer.setStyle(passwordrwarn, 'display', 'none');
      } else {
        this.submitif = false;
        this.renderer.addClass(passwordrbox, 'checknotpass');
        this.renderer.setStyle(passwordrwarn, 'display', 'block');
    }
  }

  namecheck(): void {
      const name = this.model.name;
      const namebox = this.el.nativeElement.querySelector('#name-box');
      const namewarn = this.el.nativeElement.querySelector('#name-box-warning');
      if (name !== null && name.length < 10){
        // 用户名检车通过
        this.submitif = true;
        this.renderer.removeClass(namebox, 'checknotpass');
        this.renderer.addClass(namebox, 'checkpass');
        this.renderer.setStyle(namewarn, 'display', 'none');
      } else{
        this.submitif = false;
        this.renderer.addClass(namebox, 'checknotpass');
        this.renderer.setStyle(namewarn, 'display', 'block');
      }
  }

  smscheck(): void {
      const sms = this.truesms;
      const smsbox = this.el.nativeElement.querySelector('#sms-box');
      const smswarn = this.el.nativeElement.querySelector('#sms-box-warning');

      if (sms === this.truesms){
        // 短信验证码检查通过
        this.submitif = true;
        this.renderer.removeClass(smsbox, 'checknotpass');
        this.renderer.addClass(smsbox, 'checkpass');
        this.renderer.setStyle(smswarn, 'display', 'none');
      } else {
        this.submitif = false;
        this.renderer.addClass(smsbox, 'checknotpass');
        this.renderer.setStyle(smswarn, 'display', 'block');
      }
  }

  identifiercheck(): void {
      const identifierbox = this.el.nativeElement.querySelector('#identifier-box');
      const identifierwarn = this.el.nativeElement.querySelector('#identifier-box-warning');
      const identifier = this.trueidentifier;
      const button = this.el.nativeElement.querySelector('#smsbutton');

      if (identifier === this.trueidentifier){
        // 图片验证码检查通过
        this.submitif = true;
        this.renderer.removeClass(identifierbox, 'checknotpass');
        this.renderer.addClass(identifierbox, 'checkpass');
        this.renderer.setStyle(button, 'margin-top', '-40px');
        this.renderer.setStyle(identifierwarn, 'display', 'none');
      } else {
        this.submitif = false;
        this.renderer.setStyle(button, 'margin-top', '30px');
        this.renderer.addClass(identifierbox, 'checknotpass');
        this.renderer.setStyle(identifierwarn, 'display', 'block');
      }
  }

  phonecheck(): void {
    const phonebox = this.el.nativeElement.querySelector('#phone-number-box');
    const phone = this.el.nativeElement.querySelector('#phone-box-warning');
    const phonenumber = this.model.phone;
    if (this.model.phone != null) {
      let temp = null;
      let flag = null;

      if (phonenumber.length !== 11){
        this.submitif = false;
        this.renderer.setStyle(phone, 'display', 'block');
        this.warnmessage = '手机号必须为11位';
        this.renderer.addClass(phonebox, 'checknotpass');
        return ;
      }
      for (let i = 0; i < phonenumber.length; i++) {
        temp = phonenumber.charAt(i);
        if (temp < '1' || temp > '9') {
          flag = false;
        }
      }
      if (flag === false) {
        this.submitif = flag;
        this.renderer.setStyle(phone, 'display', 'block');
        this.warnmessage = '手机号不能包含处数字以外的字符';
        this.renderer.addClass(phonebox, 'checknotpass');
        return;
      }
      // 手机号检查通过
      this.submitif = true;

      // 检查手机号码是否已经在数据库中
      // this.generalService.checkUserPhone(phonenumber);

      this.renderer.removeClass(phonebox, 'checknotpass');
      this.renderer.addClass(phonebox, 'checkpass');
      this.renderer.setStyle(phone, 'display', 'none');
    } else {
      this.renderer.addClass(phonebox, 'checknotpass');
      this.renderer.setStyle(phone, 'display', 'block');
    }
  }
}

