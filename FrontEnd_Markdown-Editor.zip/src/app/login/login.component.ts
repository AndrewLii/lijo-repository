import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User, Article, Directory } from '../define';
import { GeneralService } from '../general.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  validateForm: FormGroup;
  user: User = null;

  constructor(private fb: FormBuilder, private service: GeneralService, private router: Router) { }

  ngOnInit() {
    this.user =  this.service.userGet();

    this.validateForm = this.fb.group({
      userName: [ this.user.email, [ Validators.required ] ],
      password: [ this.user.password, [ Validators.required ] ],
      remember: [ true ]
    });
  }

  submitForm(): void {
    for (const i of Object.keys(this.validateForm.controls)) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }

    if (this.user.email !== '' && this.user.password !== '') {
      let trueUser: User = new User('', '', '', '', null);

      this.service.userLogin(this.user.email)
        .subscribe(
          tempUser => trueUser = tempUser,
          () => console.log('error'),
          () => this.passwordCheck(trueUser)
        );

      this.passwordCheck(trueUser);
    }
  }

  passwordCheck(trueUser: User): void {
    console.log('true' + trueUser.password);
    console.log('this' + this.user.password);
    if (this.user.password === trueUser.password) {
      this.user = trueUser;
      this.service.userSet(this.user);
      this.router.navigate(['index']);
    }

  }

}
