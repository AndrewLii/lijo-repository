import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GeneralService } from '../general.service';
import { User } from '../define';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  validateForm: FormGroup;
  user: User;
  rePassword: string;


  constructor(private fb: FormBuilder, private service: GeneralService, private router: Router) { }

  confirmationValidator = (control: FormControl): { [ s: string ]: boolean } => {
    if (!control.value) {
      return { required: true };
    } else if (control.value !== this.validateForm.controls.password.value) {
      return { confirm: true, error: true };
    }
  }

  ngOnInit() {
    this.user = this.service.userGet();

    this.validateForm = this.fb.group({
      email: [ null, [ Validators.required ] ],
      password: [ null, [ Validators.required ] ],
      rePassword: [ null, [ Validators.required, this.confirmationValidator ] ],
      nickName: [ null, [ Validators.required ] ],
      phoneNumberPrefix: ['+86'],
      phoneNumber: [ null, [ Validators.required ] ],
      captcha: [ null, [ Validators.required ] ],
      agree: [ false, [ Validators.required ] ]
      });
  }

  submitForm(): void {
    for (const i of Object.keys(this.validateForm.controls)) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }

    if (this.validateForm.valid) {

      this.service.userSet(this.user);
      this.service.userRegister(this.user);
      this.router.navigate(['index']);
    }
  }

  updateConfirmValidator(): void {
    Promise.resolve().then(() => this.validateForm.controls.rePassword.updateValueAndValidity());
  }

  getCaptcha(e: MouseEvent): void {

  }

}
