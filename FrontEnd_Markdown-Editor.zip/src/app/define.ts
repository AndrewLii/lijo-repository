export class User {
  constructor(
    public email: string,
    public nickName: string,
    public password: string,
    public phoneNumber: string,
    public directorySet: Directory[]
  ) {}
}

export class Directory {
  constructor(
    public name: string,
    public userEmail: string,
    public directoryId: string,
    public articleSet: Article[]
  ) {}
}

export class Article {
  constructor(
    public directoryId: string,
    public title: string,
    public srcText: string
  ) {}
}


