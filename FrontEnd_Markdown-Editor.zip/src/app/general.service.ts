import { Injectable } from '@angular/core';
import { User, Directory, Article } from './define';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { auditTime, catchError } from 'rxjs/operators';

const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }) };

const loginUrl = '/LoginServlet';
const registerUrl = '/RegisterServlet';
const getDirectoryUrl = '/DirectoryGetServlet';
const addDirectoryUrl = '/DirectoryAddServlet';
const getArticleUrl = '/ArticleGetServlet';
const addArticleUrl = '/ArticleAddServlet';
const saveArticleUrl = '/ArticleSaveServlet';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {
  private user: User = {
    email: '',
    nickName: '',
    password: '',
    phoneNumber: '',
    directorySet: null
  };

  constructor(private http: HttpClient) { }

  public userGet(): User {
    return this.user;
  }

  public userSet(user: User): void {
    this.user = user;
  }

  userLogin(email: string): Observable<User> {
    const params = new HttpParams()
      .set('email', email);

    return this.http.post<User>(loginUrl, params, httpOptions);
  }

  userRegister(user: User): void {
    const params = new HttpParams()
      .set('email', user.email)
      .set('nickName', user.nickName)
      .set('password', user.password)
      .set('phoneNumber', user.phoneNumber);

    this.http.post(registerUrl, params, httpOptions)
      .subscribe(() => {
        console.log('xxxx');
      },
        (err: HttpErrorResponse) => {
        console.log(err.error);
        console.log(err.name);
        console.log(err.message);
        console.log(err.status);
        });
  }

  directoryGet(email: string): Observable<Directory[]> {
    const params = new HttpParams()
      .set('email', email);

    return this.http.post<Directory[]>(getDirectoryUrl, params, httpOptions).pipe(
      catchError(this.handleError('directoryGet', []))
    );
  }

  directoryAdd(directory: Directory): void {
    const params = new HttpParams()
      .set('name', directory.name)
      .set('directoryId', directory.directoryId)
      .set('userEmail', directory.userEmail);

    this.http.post(addDirectoryUrl, params, httpOptions)
      .subscribe(
        () => {
          console.log('directoryAdd!');
        },
        (err: HttpErrorResponse) => {
          console.log(err.error);
          console.log(err.name);
          console.log(err.message);
          console.log(err.status);
        }
      );
  }

  articleGet(directoryId: string): Observable<Article[]> {
    const params = new HttpParams()
      .set('directoryId', directoryId);

    return this.http.post<Article[]>(getArticleUrl, params, httpOptions).pipe(
      catchError(this.handleError('articleGet', []))
    );
  }

  articleAdd(article: Article): void {
    const params = new HttpParams()
      .set('title', article.title)
      .set('directoryId', article.directoryId)
      .set('srcText', article.srcText);

    this.http.post(addArticleUrl, params, httpOptions)
      .subscribe(
        () => {
          console.log('ArticleAdd!');
        },
        (err: HttpErrorResponse) => {
          console.log(err.error);
          console.log(err.name);
          console.log(err.message);
          console.log(err.status);
        }
      );
  }

  articleSave(article: Article): void {
    const params = new HttpParams()
      .set('title', article.title)
      .set('directoryId', article.directoryId)
      .set('srcText', article.srcText);

    this.http.post(saveArticleUrl, params, httpOptions)
      .subscribe(
        () => {
          console.log('ArticleSave!');
        },
        (err: HttpErrorResponse) => {
          console.log(err.error);
          console.log(err.name);
          console.log(err.message);
          console.log(err.status);
        }
      );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.log(error);
      return of(result as T);
    };
  }
}
