import { Component, OnInit, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import { trigger, state, style, animate, transition, keyframes } from '@angular/animations';
import * as MarkdownIt from 'markdown-it';
import { Observable, Subscription, of, fromEvent} from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Router } from '@angular/router';
import { GeneralService } from '../general.service';
import { User, Directory, Article } from '../define';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css'],
  animations: [
    trigger('menuState', [
      state('inactive', style({ width: '0', display: 'none' })),
      state('active', style({ width: '380px', display: 'block' })),
      transition('inactive <=> active', animate('0.3s ease-out'))
    ]),
    trigger('directoryGroup', [
      state('inactive', style({ transform: 'translate(0, 0)' })),
      state('active', style({ transform: 'translate(0, -35px)' })),
      transition('inactive <=> active', animate('0.3s ease-in-out'))
    ]),
    trigger('articleGroup', [
      state('inactive', style({ transform: 'translate(0, 0)' })),
      state('active', style({ transform: 'translate(0, -35px)' })),
      transition('inactive <=> active', animate('0.3s ease-in-out'))
    ])
  ]
})
export class IndexComponent implements OnInit, AfterViewInit {

  public outTxt: any;
  isCollapsed = 'inactive';
  directoryGroup = 'inactive';
  articleGroup = 'inactive';

  leftScroll: Subscription = null;
  rightScroll: Subscription = null;

  leftDiv = null;
  rightDiv = null;

  newDirectoryTitle = '';
  newArticleTitle = '';

  user: User;
  article = new Article('', '', '');

  constructor(private el: ElementRef, private render: Renderer2, private service: GeneralService) { }


  ngOnInit() {
    this.user = this.service.userGet();
    this.getDirectory();
  }

  ngAfterViewInit() {
    this.leftDiv = this.el.nativeElement.querySelector('#srcText');
    this.rightDiv = this.el.nativeElement.querySelector('#outText');

    this.leftScroll = fromEvent(this.leftDiv, 'scroll')

      .subscribe((event: Event) => {
        this.handleScroll(this.leftDiv);
      });

    this.rightScroll = fromEvent(this.rightDiv, 'scroll')

      .subscribe((event: Event) => {
        this.handleScroll(this.rightDiv);
      });
  }

  public handleScroll(dom) {
    let scrollProportion: number;
    let scrollTopMaxLeft: number;
    let containerHeight: number;
    let scrollTopMaxRight: number;

    containerHeight = this.el.nativeElement.querySelector('#container').offsetHeight;
    scrollTopMaxLeft = this.leftDiv.scrollHeight - containerHeight;
    scrollTopMaxRight = this.rightDiv.scrollHeight - containerHeight;

    scrollProportion = scrollTopMaxLeft / scrollTopMaxRight;

    console.log('容器高度:' + containerHeight);
    console.log('左窗口实际高度:' + this.leftDiv.scrollHeight + '左窗口最大滚动高度:' + scrollTopMaxLeft);
    console.log('又窗口实际高度:' + this.rightDiv.scrollHeight + '右窗口最大滚动高度:' + scrollTopMaxRight);

    if (dom === this.leftDiv) {
      console.log('左为主动窗口:' + scrollProportion);
      this.rightDiv.scrollTop = this.leftDiv.scrollTop / scrollProportion ;
      console.log('右窗口被动滚动:' + this.rightDiv.scrollTop);
    } else {
      console.log('右为主动窗口:' + scrollProportion);
      this.leftDiv.scrollTop =  this.rightDiv.scrollTop * scrollProportion;
      console.log('左窗口被动滚动:' + this.leftDiv.scrollTop);
    }
  }

  public srcChange($event): void {
    this.service.articleSave(this.article);

    const md = new MarkdownIt();
    this.outTxt = md.render($event);
  }

  public toggleCollapsed(): void {
    this.isCollapsed = this.isCollapsed === 'inactive' ? 'active' : 'inactive';
  }

  getDirectory(): void {
    this.service.directoryGet(this.user.email)
      .subscribe(
        directoryset => this.user.directorySet = directoryset,
        () => console.log('getDirectoryError'),
        () => this.getArticle()
      );
  }

  newDirectory(): void {
    this.newDirectoryShow();

    let newDirectory: Directory;
    if (this.newDirectoryTitle !== '') {
      newDirectory = new Directory(this.newDirectoryTitle, this.user.email, this.newDirectoryTitle, []);
      this.user.directorySet.push(newDirectory);

      this.service.directoryAdd(newDirectory);
    }
  }

  getArticle(): void {
    for (let i = 0; i < this.user.directorySet.length; i++) {
      this.service.articleGet(this.user.directorySet[i].directoryId)
        .subscribe(articleset => this.user.directorySet[i].articleSet = articleset,
          () => console.log('getArticleError'),
          () => console.log(this.user.directorySet[i].articleSet));

      // console.log(this.user.directorySet[i].articleSet);
    }
  }

  newArticle(directory: Directory): void {
    this.newArticleShow();

    // console.log(directory.name);

    let newArticle: Article;
    if (this.newArticleTitle !== '') {
      newArticle = new Article(directory.directoryId, this.newArticleTitle, '');
      console.log(newArticle.directoryId, newArticle.title, newArticle.srcText);
      directory.articleSet.push(newArticle);
      this.service.articleAdd(newArticle);
    }
  }

  newDirectoryShow(): void {
    this.directoryGroup = this.directoryGroup === 'inactive' ? 'active' : 'inactive';
  }

  newArticleShow(): void {
    this.articleGroup = this.articleGroup === 'inactive' ? 'active' : 'inactive';
  }

  setSrcText(article: Article): void {
    this.article = article;

    const md = new MarkdownIt();
    this.outTxt = md.render(this.article.srcText);
  }

}
