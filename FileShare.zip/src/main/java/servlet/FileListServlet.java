package servlet;

import com.lizhuo.hdfstools.DateTools;
import com.lizhuo.hdfstools.HDFSTools;
import com.lizhuo.model.File;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author lizhuo
 * @create 2019-07-16:51
 */
@WebServlet(name = "FileListServlet", urlPatterns = "/filelist")
public class FileListServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HDFSTools hdfsTools = new HDFSTools();
        RemoteIterator<LocatedFileStatus> remoteIterator = hdfsTools.list("/upload");
        ArrayList<com.lizhuo.model.File> fileList = new ArrayList<>();

        while (remoteIterator.hasNext()) {
            LocatedFileStatus locatedFileStatus = remoteIterator.next();
            Path path = locatedFileStatus.getPath();
            long modificationTime = locatedFileStatus.getModificationTime();

            String createTime = DateTools.format(modificationTime);
            String fileName = path.getName();
            File file = new File(fileName, createTime);

            fileList.add(file);

            System.out.println(fileList.get(0).fileName);
        }

        req.setAttribute("fileList", fileList);
        req.getRequestDispatcher("/list.jsp").forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
