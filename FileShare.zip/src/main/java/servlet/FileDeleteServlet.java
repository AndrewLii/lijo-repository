package servlet;

import com.lizhuo.hdfstools.HDFSTools;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author lizhuo
 * @create 2019-07-19:48
 */
@WebServlet(name = "FileDeleteServlet", urlPatterns = "/delete")
public class FileDeleteServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HDFSTools hdfsTools = new HDFSTools();

        String fileName = req.getParameter("fileName");
        String destPath = "/upload/" + fileName;

        Boolean ifDelete = hdfsTools.delete(destPath);

        if (ifDelete) {
           req.getRequestDispatcher("/filelist").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
