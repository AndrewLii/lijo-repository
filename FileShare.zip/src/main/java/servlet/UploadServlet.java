package servlet;

import com.lizhuo.hdfstools.HDFSTools;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * @author lizhuo
 * @create 2019-07-20:23
 */
@WebServlet(name = "UploadServlet", urlPatterns = "/upload")
public class UploadServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        DiskFileItemFactory factory = new DiskFileItemFactory();
        HDFSTools hdfsTools = new HDFSTools();

        // 核心API——ServletFileUpload，负责处理上传的文件数据，并将表单中每个输入项封装成一个FileItem对象
        ServletFileUpload servletFileUpload = new ServletFileUpload(factory);

        servletFileUpload.setHeaderEncoding("UTF-8");

        try {
            List<FileItem> fileItems = servletFileUpload.parseRequest(req);

            if(fileItems != null && fileItems.size() > 0) {
                String fileName = null;
                InputStream inputStream = null;



                for (FileItem fileItem: fileItems) {
                    if (!fileItem.isFormField()) {
                        // 选择的上传文件名字
                        fileName = fileItem.getName();
                        // 选择的上传文件输入流(也就是文件的二进制流)
                        inputStream = fileItem.getInputStream();
                    }
                }

                // 目标路径：/upload/上传文件名
                String destPath = "/upload/" + fileName;
                boolean ifUpload = hdfsTools.upLoad(inputStream, destPath);

                System.out.println(destPath + " if file upload successfully: " + ifUpload);

                if (ifUpload) {
                   req.getRequestDispatcher("/filelist").forward(req, resp);
                } else {
                    req.getRequestDispatcher("upload.jsp").forward(req, resp);
                    req.setAttribute("msg", "file upload unsuccessfully!");
                }
            }
        } catch (FileUploadException e) {
            e.printStackTrace();
        }
    }
}
