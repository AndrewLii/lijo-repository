package servlet;

import com.lizhuo.hdfstools.HDFSTools;
import org.apache.hadoop.fs.FSDataInputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * @author lizhuo
 * @create 2019-07-20:22
 */
@WebServlet(name = "FileDownloadServlet", urlPatterns = "/download")
public class FileDownloadServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HDFSTools hdfsTools = new HDFSTools();

        String fileName = req.getParameter("fileName");
        String destPath = "/upload/" + fileName;

        FSDataInputStream fsDataInputStream = hdfsTools.getFSDataInputStream(destPath);
        BufferedInputStream bufferedInputStream = new BufferedInputStream(fsDataInputStream);
        byte[] buffer = new byte[bufferedInputStream.available()];
        bufferedInputStream.read(buffer);

        fsDataInputStream.close();
        bufferedInputStream.close();
        hdfsTools.fileSystemClose();

        resp.reset();
        resp.addHeader("Content-Disposition", "attachment;filename = " + fileName);
        resp.setContentType("application/octet-stream");

        OutputStream outputStream = new BufferedOutputStream(resp.getOutputStream());
        outputStream.write(buffer);
        outputStream.flush();
        outputStream.close();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
