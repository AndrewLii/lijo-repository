package com.lizhuo.hdfstools;


import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author lizhuo
 * @create 2019-07-17:51
 */
public class DateTools {
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static String format(long modificationTime) {
        String formatTime = simpleDateFormat.format(new Date(modificationTime));

        return formatTime;
    }
}
