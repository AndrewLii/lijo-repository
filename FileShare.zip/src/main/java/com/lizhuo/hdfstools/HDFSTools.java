package com.lizhuo.hdfstools;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.IOUtils;
import org.apache.log4j.Logger;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;


/**
 * @author lizhuo
 * @create 2019-07-16:37
 */
public class HDFSTools {
    private FileSystem fileSystem;
    private Logger logger = Logger.getLogger(HDFSTools.class);
    private Configuration configuration;

    public HDFSTools() {
        configuration = new Configuration();
        configuration.set("dfs.replication", "1");
        try {
            fileSystem = FileSystem.get(new URI("hdfs://192.168.79.10:9000"), configuration, "lizhuo");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    /*
    public void put(String src, String dest) {
        try {
            fileSystem.copyFromLocalFile(new Path(src), new Path(dest));
            System.out.println("file upload successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     */

    /*
    public void putByIOUtils(String src, String dest) {
        FileInputStream fileInputStream = null;
        FSDataOutputStream fsDataOutputStream = null;

        try{
            fileInputStream = new FileInputStream(src);
            fsDataOutputStream = fileSystem.create(new Path(dest));

            IOUtils.copyBytes(fileInputStream, fsDataOutputStream, configuration);
            logger.info("file upload by IO successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     */

    public RemoteIterator<LocatedFileStatus> list(String path) {
        try {
            RemoteIterator<LocatedFileStatus> remoteIterator = fileSystem.listLocatedStatus(new Path(path));

            fileSystem.close();
            return remoteIterator;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean delete(String src) {
        boolean ifDelete = false;

        try {
            ifDelete = fileSystem.delete(new Path(src), true);

            fileSystem.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ifDelete;
    }

    public FSDataInputStream getFSDataInputStream(String destPath) {
        FSDataInputStream fsDataInputStream = null;
        try {
            fsDataInputStream = fileSystem.open(new Path(destPath));

        } catch (IOException e) {
            e.printStackTrace();
        }

        return fsDataInputStream;
    }


    public boolean upLoad(InputStream inputStream, String dest){
        FSDataOutputStream fsDataOutputStream = null;
        try {
            System.out.println(dest);
            fsDataOutputStream = fileSystem.create(new Path(dest));

            IOUtils.copyBytes(inputStream, fsDataOutputStream, configuration);

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (fsDataOutputStream != null) {
                try {
                    fsDataOutputStream.close();
                    fileSystem.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

    public void fileSystemClose() {
        try {
            fileSystem.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
