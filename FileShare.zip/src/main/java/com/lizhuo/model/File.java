package com.lizhuo.model;

/**
 * @author lizhuo
 * @create 2019-07-17:43
 */
public class File {
    public String fileName;
    public String time;

    public File(String fileName, String time) {
        this.fileName = fileName;
        this.time = time;
    }

    public String getFileName() { return this.fileName; }

    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getTime() { return this.time; }

    public void setTime(String time) { this.time = time; }

    @Override
    public String toString() {
        return "File{ " + "filename = " + this.fileName + '\'' + ", time = " + this.time + '\'' + " }";
    }
}
